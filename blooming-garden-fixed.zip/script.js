const G=['images/garden-1.jpg','images/garden-2.jpg','images/garden-3.jpg','images/garden-4.jpg','images/garden-5.jpg'];
const $=s=>document.querySelector(s),sh=a=>{a=a.slice();for(let i=a.length-1;i>0;i--){const j=Math.random()*(i+1)|0;[a[i],a[j]]=[a[j],a[i]]}return a};
// c,m: first level only (partial verse). n: next verse, b: missing word, a: arrange (verse numbers)
const V=["", "يا أيها النبي لم تحرم ما أحل الله لك تبتغي مرضات أزواجك والله غفور رحيم", "قد فرض الله لكم تحلة أيمانكم والله مولاكم وهو العليم الحكيم", "وإذ أسر النبي إلى بعض أزواجه حديثا فلما نبأت به وأظهره الله عليه عرف بعضه وأعرض عن بعض فلما نبأها به قالت من أنبأك هذا قال نبأني العليم الخبير", "إن تتوبا إلى الله فقد صغت قلوبكما وإن تظاهرا عليه فإن الله هو مولاه وجبريل وصالح المؤمنين والملائكة بعد ذلك ظهير", "عسى ربه إن طلقكن أن يبدله أزواجا خيرا منكن مسلمات مؤمنات قانتات تائبات عابدات سائحات ثيبات وأبكارا", "يا أيها الذين آمنوا قوا أنفسكم وأهليكم نارا وقودها الناس والحجارة عليها ملائكة غلاظ شداد لا يعصون الله ما أمرهم ويفعلون ما يؤمرون", "يا أيها الذين كفروا لا تعتذروا اليوم إنما تجزون ما كنتم تعملون", "يا أيها الذين آمنوا توبوا إلى الله توبة نصوحا عسى ربكم أن يكفر عنكم سيئاتكم ويدخلكم جنات تجري من تحتها الأنهار يوم لا يخزي الله النبي والذين آمنوا معه نورهم يسعى بين أيديهم وبأيمانهم يقولون ربنا أتمم لنا نورنا واغفر لنا إنك على كل شيء قدير", "يا أيها النبي جاهد الكفار والمنافقين واغلظ عليهم ومأواهم جهنم وبئس المصير", "ضرب الله مثلا للذين كفروا امرأة نوح وامرأة لوط كانتا تحت عبدين من عبادنا صالحين فخانتاهما فلم يغنيا عنهما من الله شيئا وقيل ادخلا النار مع الداخلين", "وضرب الله مثلا للذين آمنوا امرأة فرعون إذ قالت رب ابن لي عندك بيتا في الجنة ونجني من فرعون وعمله ونجني من القوم الظالمين", "ومريم ابنت عمران التي أحصنت فرجها فنفخنا فيه من روحنا وصدقت بكلمات ربها وكتبه وكانت من القانتين"];
const SEG=["يا أيها الذين آمنوا توبوا إلى الله توبة نصوحا","عسى ربكم أن يكفر عنكم سيئاتكم","ويدخلكم جنات تجري من تحتها الأنهار","يوم لا يخزي الله النبي والذين آمنوا معه","نورهم يسعى بين أيديهم وبأيمانهم","يقولون ربنا أتمم لنا نورنا","واغفر لنا إنك على كل شيء قدير"];
const L=[
{n:'المستوى الأول',r:'الآيات 1–2',q:[
['c','يا أيها النبي لم تحرم','ما أحل الله لك تبتغي مرضات أزواجك والله غفور رحيم','تحلة أيمانكم والله مولاكم وهو العليم الحكيم','إنما تجزون ما كنتم تعملون','واغلظ عليهم ومأواهم جهنم وبئس المصير'],
['c','يا أيها النبي لم تحرم ما أحل الله لك','تبتغي مرضات أزواجك والله غفور رحيم','والله مولاكم وهو العليم الحكيم','نبأني العليم الخبير','وكانت من القانتين'],
['m','اختر الكلمة المناسبة','قد فرض الله لكم _____ أيمانكم','تحلة','توبة','مثلا','نارا'],
['c','قد فرض الله لكم تحلة أيمانكم','والله مولاكم وهو العليم الحكيم','والله غفور رحيم','نبأني العليم الخبير','وكانت من القانتين'],
['c','قد فرض الله لكم','تحلة أيمانكم والله مولاكم وهو العليم الحكيم','تبتغي مرضات أزواجك والله غفور رحيم','إنما تجزون ما كنتم تعملون','واغلظ عليهم ومأواهم جهنم وبئس المصير']]},
{n:'المستوى الثاني',r:'الآيات 3–4',q:[["n",2,[5,7,12]],["b",3,"فلما نبأت به وأظهره الله عليه","والله مولاكم وهو العليم الحكيم","قد فرض الله لكم تحلة أيمانكم","إن تتوبا إلى الله فقد صغت قلوبكما"],["b",3,"عرف بعضه وأعرض عن بعض","فنفخنا فيه من روحنا","فخانتاهما فلم يغنيا عنهما من الله شيئا","لا يعصون الله ما أمرهم"],["n",3,[2,8,10]],["b",4,"فقد صغت قلوبكما","فلما نبأها به قالت من أنبأك هذا","قد فرض الله لكم تحلة أيمانكم","نورهم يسعى بين أيديهم وبأيمانهم"],["a",[2,3,4]]]},
{n:'المستوى الثالث',r:'الآيات 5–6',q:[["n",4,[1,7,9]],["b",5,"أن يبدله أزواجا خيرا منكن","أن يكفر عنكم سيئاتكم","أنفسكم وأهليكم نارا","إنما تجزون ما كنتم تعملون"],["w","رتب صفات الأزواج الثماني كما وردت في الآية",["مسلمات","مؤمنات","قانتات","تائبات","عابدات","سائحات","ثيبات","وأبكارا"]],["n",5,[8,7,11]],["b",6,"قوا أنفسكم وأهليكم نارا","توبوا إلى الله توبة نصوحا","جاهد الكفار والمنافقين","لا تعتذروا اليوم"],["b",6,"عليها ملائكة غلاظ شداد","والملائكة بعد ذلك ظهير","يوم لا يخزي الله النبي","وكانت من القانتين"],["a",[4,5,6]]]},
{n:'المستوى الرابع',r:'الآيات 7–8',q:[["n",6,[8,9,3]],["b",7,"لا تعتذروا اليوم","لا يعصون الله ما أمرهم","يوم لا يخزي الله النبي","قد فرض الله لكم"],["n",7,[6,1,5]],["s",1,[2,4,6]],["s",4,[5,6,"إنما تجزون ما كنتم تعملون"]],["s",6,["ومأواهم جهنم وبئس المصير","والله مولاكم وهو العليم الحكيم","والله غفور رحيم"]],["w","رتب جمل الآية كما وردت",["يا أيها الذين آمنوا توبوا إلى الله توبة نصوحا","عسى ربكم أن يكفر عنكم سيئاتكم","ويدخلكم جنات تجري من تحتها الأنهار","يوم لا يخزي الله النبي والذين آمنوا معه","نورهم يسعى بين أيديهم وبأيمانهم","يقولون ربنا أتمم لنا نورنا","واغفر لنا إنك على كل شيء قدير"]]]},
{n:'المستوى الخامس',r:'الآيات 9–12',q:[["n",8,[1,7,4]],["n",9,[11,12,7]],["b",10,"وقيل ادخلا النار مع الداخلين","فنفخنا فيه من روحنا","ونجني من القوم الظالمين","ومأواهم جهنم وبئس المصير"],["n",10,[9,4,6]],["b",11,"رب ابن لي عندك بيتا في الجنة","ربنا أتمم لنا نورنا","فخانتاهما فلم يغنيا عنهما من الله شيئا","واغفر لنا إنك على كل شيء قدير"],["n",11,[10,3,5]],["b",12,"التي أحصنت فرجها فنفخنا فيه من روحنا","كانتا تحت عبدين من عبادنا صالحين","إذ قالت رب ابن لي عندك بيتا في الجنة","لا يعصون الله ما أمرهم ويفعلون ما يؤمرون"],["a",[9,10,11,12]]]}];
let S={scr:'w',lv:0,qi:0,ok:0,done:[0,0,0,0,0],acc:[null,null,null,null,null],prev:0,c:null,sure:0,name:''};
try{S.name=localStorage.getItem('bg66n')||''}catch(e){}
S.done=S.done.map((d,i)=>S.done.slice(0,i+1).every(Boolean)?1:0);
try{const o=JSON.parse(localStorage.getItem('bg66b'));if(o&&o.name&&!S.name)S.name=o.name}catch(e){}
const unl=i=>i==0||!!S.done[i-1];
const pkey=()=>'bg66p:'+S.name.trim().toLowerCase();
const save=()=>{try{localStorage.setItem('bg66n',S.name);localStorage.setItem(pkey(),JSON.stringify({done:S.done,acc:S.acc}))}catch(e){}};
const load=()=>{S.done=[0,0,0,0,0];S.acc=[null,null,null,null,null];try{const x=JSON.parse(localStorage.getItem(pkey()));if(x&&x.done&&x.acc){S.done=x.done.map((d,i)=>x.done.slice(0,i+1).every(Boolean)?1:0);S.acc=x.acc}}catch(e){}};
const cnt=()=>S.done.filter(Boolean).length,stage=()=>Math.min(cnt(),4);
let AC,mute=0;
function tone(f,d,t,v=.07){if(mute)return;try{AC=AC||new(window.AudioContext||window.webkitAudioContext)();const o=AC.createOscillator(),g=AC.createGain(),n=AC.currentTime+t;o.frequency.value=f;g.gain.setValueAtTime(v,n);g.gain.exponentialRampToValueAtTime(.0001,n+d);o.connect(g);g.connect(AC.destination);o.start(n);o.stop(n+d)}catch(e){}}
const sfx=k=>({g:[659,880],s:[330,294],w:[523,659,784,1047],b:[1047,1319,1568,1319,1760]}[k]).forEach((f,i)=>tone(f,k=='b'?.25:.35,i*(k=='b'?.12:.14),k=='b'?.03:.07));
const esc=s=>s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function deco(nl){let o='';S.acc.forEach((a,i)=>{if(a==null)return;let r=(i+1)*7919;const R=()=>(r=r*16807%2147483647)/2147483647,t=a>=.9?3:a>=.6?2:1,p=i===nl?' pop':'',F=['🌸','🌼','🌷','🌺'];
for(let k=0;k<(t==1?2:t==2?4:6);k++)o+=`<span class="${p}" style="left:${4+R()*88}%;top:${60+R()*30}%">${F[R()*4|0]}</span>`;if(t==3)o+='<i class="glow"></i>'});return o}
function flutter(){sfx('b');const d=$('.deco');if(!d)return;let h='';for(let i=0;i<7;i++)h+=`<span class="bf" style="left:${8+i*12}%;top:${50+(i%3)*14}%;animation-delay:${i*.25}s">🦋</span>`;d.insertAdjacentHTML('beforeend',h);setTimeout(()=>document.querySelectorAll('.bf').forEach(e=>e.remove()),5000)}
function garden(i,prev,nl,bl){const nx=Math.min(i+1,4);return `<div class="garden${prev!=null?' rev':''}">${prev!=null?`<img src="${G[prev]}" alt="">`:''}<img id="gi" src="${G[i]}" alt="حديقتك" ${prev!=null?'style="opacity:0"':''}>${bl!=null&&nx!=i?`<img id="nx" src="${G[nx]}" alt="" style="opacity:${bl}">`:''}<div class="deco">${deco(nl)}</div>${cnt()==5?'<i class="glow gold"></i>':''}</div>`}
function newQ(){const q=L[S.lv].q[S.qi],k=q[0];S.lock=0;
if(k=='a'){const cards=q[1].map(i=>V[i]);let p=cards.map((_,i)=>i);while(p.every((x,i)=>x==i))p=sh(p);S.c={k:'a',cards,pool:p,pick:[],v:'تبدأ هذه الآيات بـ: '+V[q[1][0]].split(' ').slice(0,5).join(' ')+' …'}}
else if(k=='n')S.c={k:'o',ins:'ما الآية التي تأتي بعد هذه الآية؟',v:V[q[1]],ans:V[q[1]+1],o:sh([V[q[1]+1],...sh(q[2]).slice(0,2).map(i=>V[i])]),long:1};
else if(k=='b')S.c={k:'o',ins:'اختر الجملة الناقصة من الآية',v:V[q[1]].replace(q[2],'_____'),ans:q[2],o:sh([q[2],...sh(q.slice(3)).slice(0,2)]),long:1};
else if(k=='w'){const cards=q[2];let p=cards.map((_,i)=>i);while(p.every((x,i)=>x==i))p=sh(p);const vv=V.find(v=>cards.every(c=>v.includes(c))),ix=Math.min(...cards.map(c=>vv.indexOf(c)));S.c={k:'a',ins:q[1],cards,pool:p,pick:[],cp:cards.every(x=>x.length<14),v:'بداية الآية: '+(ix>0?vv.slice(0,ix).trim():vv.split(' ').slice(0,6).join(' '))+' …'}}
else if(k=='s')S.c={k:'o',ins:'أكمل الآية بالجملة التالية',v:SEG.slice(0,q[1]).join(' ')+' …',ans:SEG[q[1]],o:sh([SEG[q[1]],...sh(q[2]).slice(0,2).map(x=>typeof x=='number'?SEG[x]:x)]),long:1};
else{const c=k=='c';S.c={k:'o',ins:c?'أكمل الآية':q[1],v:c?q[1]+' …':q[2],ans:c?q[2]:q[3],o:(()=>{const a=c?q.slice(2):q.slice(3);return sh([a[0],...sh(a.slice(1)).slice(0,2)])})()};S.c.long=S.c.o.some(x=>x.length>30)}}
function go(s){S.scr=s;S.sure=0;render()}
function start(i){if(!unl(i))return;S.lv=i;S.qi=0;S.ok=0;S.res=[];newQ();go('q')}
function pv(){if(S.qi>0){S.qi--;newQ();render()}}
const T=(id,m={})=>$('#t-'+id).innerHTML.replace(/\{\{(\w+)\}\}/g,(_,k)=>m[k]==null?'':m[k]);
const scr={
w:()=>T('w',{garden:garden(0)}),
i:()=>T('i',{name:esc(S.name)}),
x:()=>T('x',{garden:garden(stage()),lv:S.lv}),
s:()=>T('s',{garden:garden(stage()),
 journey:G.map((g,i)=>`<div class="th${i<=stage()?'':' lk'}"><img src="${g}" alt=""></div>`).join(''),
 levels:L.map((l,i)=>{const lock=!unl(i),a=S.acc[i];return `<button class="lv ${S.done[i]?'d':''}" ${lock?'disabled':''} onclick="start(${i})"><b>${lock?'🔒':i+1}</b>${l.n}<br><small>${l.r}</small><br>${lock?'<small>🔒 مغلق حتى تجتاز المستوى السابق</small>':a==null?'&nbsp;':'🌸'.repeat(a>=.9?3:a>=.6?2:1)}</button>`}).join(''),
 reset:S.sure?'اضغط مرة أخرى للتأكيد':'ابدأ من جديد',sound:mute?'🔇':'🔊'}),
q:()=>{const l=L[S.lv],n=l.q.length,c=S.c;let b;
if(c.k=='a')b=arr();else b=`<div class="ins">${c.ins}</div>${c.v?`<div class="verse${c.v.length>90?' sm':''}">${c.v}</div>`:''}<div class="opts${c.long?' lg':''}">${c.o.map((t,i)=>`<button class="opt" onclick="ans(${i})">${t}</button>`).join('')}</div><div id="fb"></div>`;
return T('q',{level:l.n,prev:S.qi>0?'<button class="ghost" onclick="pv()">السؤال السابق</button> ':'',pos:(S.qi+1)+' / '+n,pct:S.qi/n*100,body:b,garden:garden(stage(),null,-1,S.ok/n)})},
d:()=>{const l=L[S.lv],n=l.q.length,a=S.ok/n;
return T('d',{level:l.n,garden:garden(stage(),S.prev,S.lv),
 msg:a>=.9?'ما شاء الله! حديقتك تلمع بالجمال!':a>=.6?'أحسنت! أزهارك بدأت تتفتح.':'حديقتك بدأت تزدهر! راجع الآيات أكثر لتجعلها أجمل.',
 msg2:S.lv==3?'اقتربت حديقتك من الاكتمال!':a<.6?'بمزيد من المراجعة ستصبح حديقتك أجمل.':'',
 petals:'🌸'.repeat(S.ok),next:cnt()==5&&S.lv==4?"go('f')":"go('s')"})},
f:()=>T('f',{garden:garden(4),name:esc(S.name),
 confetti:Array.from({length:28},(_,i)=>`<span style="left:${(i*37)%100}%;animation-duration:${3+i%5}s;animation-delay:-${i%7}s">${['🌸','🌼','🌷','🌺'][i%4]}</span>`).join('')})};
function arr(){const c=S.c,all=c.pick.length==c.cards.length;
return `<div class="ins">${c.ins||'رتب الآيات كما وردت في السورة'}</div>${c.v?`<div class="verse sm">${c.v}</div>`:''}<div>${c.pick.map((p,j)=>`<button class="opt card${c.cp?' cp':''} ${c.done?'ok':''}" ${c.done?'disabled':''} onclick="un(${j})"><small>${j+1}</small>${c.cards[p]}</button>`).join('')||'<div class="hint">اضغط على الآيات بالترتيب الصحيح</div>'}</div><div>${c.done?'':c.pool.filter(p=>!c.pick.includes(p)).map(p=>`<button class="opt card${c.cp?' cp':''}" onclick="pk(${p})">${c.cards[p]}</button>`).join('')}</div><div id="fb">${all&&!c.done?'<button class="btn" onclick="chk()">تحقق</button>':''}</div>`}
const redo=()=>{$('#qa').innerHTML=arr()};
function pk(p){S.c.pick.push(p);redo()}function un(j){S.c.pick.splice(j,1);redo()}
function chk(){const c=S.c,ok=c.pick.every((p,j)=>p==j);c.done=1;c.pick=c.cards.map((_,i)=>i);S.res[S.qi]=ok;S.ok=S.res.filter(Boolean).length;redo();fb(ok)}
function ans(i){if(S.lock)return;S.lock=1;const c=S.c,ok=c.o[i]===c.ans;S.res[S.qi]=ok;S.ok=S.res.filter(Boolean).length;
document.querySelectorAll('.opt').forEach((b,j)=>{b.disabled=true;if(c.o[j]===c.ans)b.classList.add('ok');else if(j===i)b.classList.add('no')});fb(ok)}
function fb(ok){sfx(ok?'g':'s');const e=$('#nx');if(e)e.style.opacity=S.ok/L[S.lv].q.length;const last=S.qi+1==L[S.lv].q.length;$('#fb').innerHTML=`<div class="fb ${ok?'g':'a'}">${ok?'✓ أحسنت!':'🌱 قريب! الإجابة الصحيحة بالأخضر'}</div><button class="btn" onclick="nx()">${last?'أنهِ المستوى':'التالي'}</button>`}
function nx(){if(S.qi+1<L[S.lv].q.length){S.qi++;newQ();render();return}
if(L[S.lv].q.length-S.ok>3){sfx('s');go('x');return}S.prev=stage();S.done[S.lv]=1;S.acc[S.lv]=Math.max(S.acc[S.lv]||0,S.ok/L[S.lv].q.length);save();sfx('w');go('d')}
function gn(){const v=$('#nm').value.trim();if(!v){$('#nm').placeholder='اكتب اسمك أولًا';$('#nm').focus();return}S.name=v;load();save();go('s')}
function op(){$('#gate').classList.add('open');$('#gb').style.display='none';sfx('w');setTimeout(()=>{$('#bd').classList.add('on');sfx('w')},2300)}
function rs(){if(!S.sure){S.sure=1;render();return}S.sure=0;S.done=[0,0,0,0,0];S.acc=[null,null,null,null,null];save();go('w')}
function render(){if(S.scr=='q'&&!unl(S.lv))S.scr='s';$('#app').innerHTML=(['w','q'].includes(S.scr)?'':T('hb'))+scr[S.scr]();scrollTo(0,0);if(S.scr=='d'){setTimeout(()=>{const g=$('#gi');g&&(g.style.opacity=1)},300);flutter()}}
render();
